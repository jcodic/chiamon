package com.ddx.chiamon.common.data;

import java.util.Date;

/**
 *
 * @author ddx
 */
public class LogErrorEntry {

    private Date dt;

    public Date getDt() {
        return dt;
    }

    public void setDt(Date dt) {
        this.dt = dt;
    }

}