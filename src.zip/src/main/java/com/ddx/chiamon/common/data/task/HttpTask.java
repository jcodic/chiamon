package com.ddx.chiamon.common.data.task;

/**
 *
 * @author ddx
 */
public class HttpTask extends Task {

    protected String packetUid;

    public String getPacketUid() {
        return packetUid;
    }

    public void setPacketUid(String packetUid) {
        this.packetUid = packetUid;
    }
    
}