package com.ddx.chiamon.common.data;

/**
 *
 * @author ddx
 */
public class Vars {

    public static final long SECOND = 1000;
    public static final long MINUTE = 60 * SECOND;
    public static final long HOUR = 60 * MINUTE;
    public static final long DAY = 24 * HOUR;

}
