package com.ddx.chiamon.client.data;

/**
 *
 * @author ddx
 */
public class DiskSmart extends com.ddx.chiamon.common.data.DiskSmart  {
    
    private long diskId;

    public long getDiskId() {
        return diskId;
    }

    public void setDiskId(long diskId) {
        this.diskId = diskId;
    }
    
}